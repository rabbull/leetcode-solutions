//
// Created by Karl on 2018/7/4.
//

#ifndef ISPALINDROME_SOLUTION_H
#define ISPALINDROME_SOLUTION_H


#include <string>

class Solution {
public:
    bool isPalindrome(std::string);
};


#endif //ISPALINDROME_SOLUTION_H
